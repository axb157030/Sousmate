window.onload=function(){
	//$("#danClock").fadeOut();
	var posDanClock;
	var posWhatSous;
	var posIndex;
	var sousIndex;
	var id;
	sousIndex = document.getElementById("sousI");
	console.log("ethiylguovwtehw");


		$("#danClock").fadeOut(1);
		console.log("ethwtehwbbbbbbbbbb");
		console.log("ethwtehw");
		//posWhatSous = $("#whatSous").offset();
	   posIndex = $("#sousI").offset();
		var height = $(window).scrollTop();
		//console.log("height " + height);
		//console.log("danClock " + posDanClock.top);
		if(height >= 250)
		{
console.log(height);
			$("#danClock").fadeIn(1500);

		}
		
		


	$(window).scroll(function() {

		var height = $(window).scrollTop();
		posDanClock = $("#danClock").offset(); // Needs to be set here. position of #danClock changes depending on 
		posIndex = $("#sousI").offset();
		//console.log("height2 " + height);
		//console.log("danClock2 " + posDanClock.top);
		var fontPx = 24;
		
		
			
			//console.log("fontSize rv " + posIndex.top);

		if(posIndex.top > 200)
		{
			sousIndex.style.fontSize = "1em";
			sousIndex.style.transition = "font-size 1s"; // Works fantastic! setinterval should only be used if this does not work and really only for on click functions
		}
		
		else
		{
			sousIndex.style.fontSize = "1.5em";
		}
		


	if(height >= posDanClock.top)
	{
		//document.getElementById("danClock").style.visibility = "visible";
		console.log("hey i am here");
		$("#danClock").fadeIn(1500);

	}
	    
});

$("#recipeSubmit").click(function(e){ 
	//var form = new FormData(document.getElementById("form"));
	//var recipe = $("nameRecipe").value;
	var recipe = document.getElementById('nameRecipe').value;
	console.log("recipe upload ", recipe);
	url = "https://www.themealdb.com/api/json/v1/1/search.php?s=" + recipe;


	$.getJSON(url, function (data) {
		e.preventDefault();
		var video;
		console.log("jj ", data.meals[0].strYoutube);
		video = data.meals[0].strYoutube;
		video = video.substr(32, 43);
		localStorage.setItem("foodTitle", data.meals[0].strMeal);
		localStorage.setItem("foodImage", data.meals[0].strMealThumb);
		localStorage.setItem("i1", data.meals[0].strMeasure1 + " " +  data.meals[0].strIngredient1);
		localStorage.setItem("i2", data.meals[0].strMeasure2 + " " +  data.meals[0].strIngredient2);
		localStorage.setItem("i3", data.meals[0].strMeasure3 + " " +  data.meals[0].strIngredient3);
		localStorage.setItem("i4", data.meals[0].strMeasure4 + " " +  data.meals[0].strIngredient4);
		localStorage.setItem("i5", data.meals[0].strMeasure5 + " " +  data.meals[0].strIngredient5);
		localStorage.setItem("i6", data.meals[0].strMeasure6 + " " +  data.meals[0].strIngredient6);
		localStorage.setItem("i7", data.meals[0].strMeasure7 + " " +  data.meals[0].strIngredient7);
		localStorage.setItem("i9", data.meals[0].strMeasure8 + " " +  data.meals[0].strIngredient8);
		localStorage.setItem("i10", data.meals[0].strMeasure10 + " " +  data.meals[0].strIngredient10);
		localStorage.setItem("i11", data.meals[0].strMeasure11 + " " +  data.meals[0].strIngredient11);
		localStorage.setItem("i12", data.meals[0].strMeasure12 + " " +  data.meals[0].strIngredient12);
		localStorage.setItem("i13", data.meals[0].strMeasure13 + " " +  data.meals[0].strIngredient13);
		localStorage.setItem("i14", data.meals[0].strMeasure14 + " " +  data.meals[0].strIngredient14);
		localStorage.setItem("i15", data.meals[0].strMeasure15 + " " +  data.meals[0].strIngredient15);
		localStorage.setItem("i16", data.meals[0].strMeasure16 + " " +  data.meals[0].strIngredient16);
		localStorage.setItem("i17", data.meals[0].strMeasure17 + " " +  data.meals[0].strIngredient17);
		localStorage.setItem("i18", data.meals[0].strMeasure18 + " " +  data.meals[0].strIngredient18);
		localStorage.setItem("i19", data.meals[0].strMeasure19 + " " +  data.meals[0].strIngredient19);
		localStorage.setItem("i20", data.meals[0].strMeasure20 + " " +  data.meals[0].strIngredient20);
		
		localStorage.setItem("Instructions", data.meals[0].strInstructions);
		localStorage.setItem("cookVid", video);

		window.open('recipInstruc.html', '_blank');
		
		});
	});
	


	// https://stackoverflow.com/questions/17441065/how-to-detect-scroll-position-of-page-using-jquery
	// https://www.programmableweb.com/category/all/apis?keyword=recipe
}